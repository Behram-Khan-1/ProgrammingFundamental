#include <stdio.h>

int main() {
    int x,y,a,b,c;
    x = y = a = b = c = 515;
    int sum;

    sum = x + y + a + b + c;

    printf("Sum of all variables: %d\n", sum);

    return 0;
}