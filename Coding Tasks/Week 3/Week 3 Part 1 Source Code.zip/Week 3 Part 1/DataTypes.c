#include<stdio.h>

int main()
{
    //write program that has int, char and float and print their values
    int a = 10;
    char b = 'A';
    float c = 10.5;
    
    printf("Integer: %i\n", a);
    printf("Character: %c\n", b);
    printf("Float: %f\n", c);
    
    return 0;
}