#include<stdio.h>

int main()
{
    int a;
    float b;
    char c;
    printf("Size of int is %i bytes\n", sizeof(a));
    printf("Size of float is %i bytes\n", sizeof(b));
    printf("Size of char is %i bytes\n", sizeof(c));
}