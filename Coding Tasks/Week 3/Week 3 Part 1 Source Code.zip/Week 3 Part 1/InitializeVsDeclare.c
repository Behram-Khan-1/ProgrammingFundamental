#include<stdio.h>

void CharAndIntDiff();
int main()
{
    int a;
    printf("%i \n", a);
    a = 5;
    printf("%i \n", a);

    float x ;
    printf("%f \n", x);
    x = 5.5;
    printf("%f \n", x);

    char t;
    printf("%c \n", t);
    t = 'a';
    printf("%c \n", t);

    //Cannot Redeclare or initialze
    // float a;
    // float x;
    // float t;

    // char a;
    // char x;
    // char t;

    // int a;
    // int x;
    // int t;
}