#include <stdio.h>

int main() {
    printf("Hello, World!\n");
    printf("This is a new line.\n");
    printf("This is a horizontal tab:\tTab\n");
    printf("This is a backslash: \\\\ \n");
    printf("This is a double quote: \\\" \n");
    printf("This is a single quote: \\' \n");
    printf("This is a beep sound: \a \n");

    return 0;
}