#include<stdio.h>
int main()
{

    int number = 5;
    
    if (number > 0) 
    {
        printf("The number is positive.\n");
    } 
    else 
    {
        printf("The number is not positive.\n");
    }

}