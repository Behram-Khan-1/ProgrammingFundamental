#include<stdio.h>

int main()
{
    int FirstNum = 1;
    int SecondNum = 2;
    float ThirdNum = 2.2;
    printf("Hello World %i %i %f",  FirstNum,SecondNum,ThirdNum);
    return 0;
}