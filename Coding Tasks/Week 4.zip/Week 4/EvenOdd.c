#include <stdio.h>

int main() {
    int number = 10;

    // Check if the number is even
    if (number % 2 == 0) {
        printf("The number is even.\n");
    }

    return 0;
}